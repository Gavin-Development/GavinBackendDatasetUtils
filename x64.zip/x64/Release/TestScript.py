import LoadTrainData as LTD
import time
import base64
import pickle

testlist = []
testlist = LTD.LoadTrainDataST(5000000, "C:/Users/harve/Desktop/Gavin/GavinTraining/", "Tokenizer-3.to", 69108,66109, 52, 0)

print(len(testlist))
print(testlist[0:2])
